def double_char(str):
  result = ""
  for i in str:
    result+=i*2
    
  return result
