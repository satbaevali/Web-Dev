def diff21(n):
  diff = abs(21-n)
  
  if n>21:
    diff *= 2
  
  return diff
