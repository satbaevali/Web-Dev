def max_end3(nums):
  if nums[0]>nums[2]:
    return [nums[0]]*3
  else:
    return [nums[2]]*3
