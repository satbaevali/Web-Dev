def has23(nums):
  return nums[0]==2 or nums[1]==2 or nums[0]==3 or nums[1]==3
