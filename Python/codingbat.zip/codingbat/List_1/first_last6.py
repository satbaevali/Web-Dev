def first_last6(nums):
  return nums[0]==6 or nums[len(nums)-1]==6
