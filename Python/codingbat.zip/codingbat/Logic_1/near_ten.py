def near_ten(num):
  lst = [0,1,2,8,9]
  return num%10 in lst