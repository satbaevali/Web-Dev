def cigar_party(cigars, is_weekend):
  return 40<=cigars<=60 or (is_weekend and cigars>=40)