def extra_end(str):
  last2 = str[-2:]
  
  return last2*3
