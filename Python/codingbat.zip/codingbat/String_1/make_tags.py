def make_tags(tag, word):
  return "<{0}>{1}</{0}>".format(tag,word)
