def first_half(str):
  middle = len(str)//2
  
  return str[:middle]
