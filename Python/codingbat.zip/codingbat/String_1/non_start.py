def non_start(a, b):
  first = a[1:]
  second = b[1:]
  
  return first+second
