def string_times(str, n):
  multiple_string = ""
  for i in range(n):
    multiple_string+=str
    
  return multiple_string
